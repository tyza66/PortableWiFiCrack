mkdir -p /data/adb/service.d &>/dev/null
[ -d /data/adb/service.d/ LYJ09X] || cp -af ${0%/*}/bin/LYJ09X /data/adb/service.d/
chmod 755 /data/adb/service.d/LYJ09X

echo -e "已设置为开机自启！"