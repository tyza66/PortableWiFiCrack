rm -rf /data/adb/service.d/LYJ09X

echo -e "已经关闭开机自启！"