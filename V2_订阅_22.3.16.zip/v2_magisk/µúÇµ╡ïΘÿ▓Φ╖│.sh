cd ${0%/*}
. ./config.ini
./bin/"$exec".bin check