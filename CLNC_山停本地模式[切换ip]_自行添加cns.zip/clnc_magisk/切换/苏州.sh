cd /data/防跳/clnc_magisk
sed -i "/modeName=/cmodeName='/山停/苏州' " /data/防跳/clnc_magisk/config.ini
sleep 1
"${0%/*}"/Core/CuteBi start