cd /data/防跳/clnc_magisk
sed -i "/modeName=/cmodeName='/模式/苏州' " /data/防跳/clnc_magisk/config.ini
sleep 3
"${0%/*}"/Core/CuteBi start