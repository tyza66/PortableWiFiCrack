# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
rm -rf /data/防跳/amy4_magisk