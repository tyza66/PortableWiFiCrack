#快游戏账号(https://www.quick-connect.top)
username='xxyy@gmail.com'

#快游戏密码
password='xxyy'

#节点目录
outDir="./快游戏节点"

#设置后将替换模式中的[MHOST]
repHost=''

#设置后将替换模式中的[PATH]
repPath=''

#设置后替换模式中的[Phone]
repPhone='13232325252'

#订阅host
subHost="https://subscribe.pingguo.buzz"

echo "节点保存目录为：$PWD/$outDir"
echo '节点文件 需要复制到 全局节点 或 海内节点 文件夹才可以用'
echo
"${0%/*}"/../Core/MLBox -quickSubsrcibe="-url=${subHost}/quickApp/subscribe.php?username=${username}&password=${password}&sv=1.1 -outDir=$outDir -repHost=$repHost -repPath=$repPath -repPhone=$repPhone"
[ "$?" != '0' ] && exec echo "获取订阅失败"
cd "$outDir" || exec "获取订阅失败"
[ -n "$(ls)" ] || exec echo "订阅节点为空"
