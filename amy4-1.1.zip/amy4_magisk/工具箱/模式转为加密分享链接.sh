#原始模式文件路径
plainTextFile='../海内节点/amy4.json'

#转换选项(1为输出到文件, 2为输出到终端)
p2lOpt='1'

"${0%/*}"/../Core/amy4 -config "$plainTextFile" -p2l "$p2lOpt"