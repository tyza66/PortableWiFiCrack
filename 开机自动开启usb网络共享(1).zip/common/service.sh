svc usb setFunctions rndis
svc usb getFunctions